//
//  LYLayoutManager.m
//  ViewControllerTest
//
//  Created by 李言 on 14-8-28.
//  Copyright (c) 2014年 ___李言___. All rights reserved.
//

#import "LYLayoutManager.h"

@implementation LYLayoutManager
- (CGFloat)layoutManager:(NSLayoutManager *)layoutManager lineSpacingAfterGlyphAtIndex:(NSUInteger)glyphIndex withProposedLineFragmentRect:(CGRect)rect
{
	// Line height is a multiple of the complete line, here we need only the extra space
	return 50;
   
}
@end
