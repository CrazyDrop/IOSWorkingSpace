//
//  FaceView.h
//  ViewControllerTest
//
//  Created by 李言 on 14-8-11.
//  Copyright (c) 2014年 ___李言___. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FaceViewTableViewCell.h"
#define FaceKeyBoardHeight  215

@protocol getFaceDelegete <NSObject>

-(void)ClickFaceName:(NSString *)faceName;
-(void)backFace;
@end
@interface FaceView : UIView<UITableViewDelegate,UITableViewDataSource>
{
    NSArray *color;
    NSDictionary *_faceMap;
}

@property (nonatomic, weak)id<getFaceDelegete>delegate;
@property (nonatomic, strong)UITextView *inputTextView;

@property (nonatomic, strong)void (^ClickFaceBtn) (NSString * facename);
@end
