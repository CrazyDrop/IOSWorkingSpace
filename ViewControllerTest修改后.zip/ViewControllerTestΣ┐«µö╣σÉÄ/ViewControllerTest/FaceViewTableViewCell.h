//
//  FaceViewTableViewCell.h
//  ViewControllerTest
//
//  Created by 李言 on 14-8-11.
//  Copyright (c) 2014年 ___李言___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FaceViewTableViewCell : UITableViewCell

{
    NSDictionary *faceMap;

  //  UIView *rootView;
}

-(void)layOutFaceView:(NSInteger)index;
@property (nonatomic, strong) UITextView *inputTextView;
//@property (nonatomic, assign)NSInteger Index;

@end
