//
//  SecondViewController.m
//  ViewControllerTest
//
//  Created by 李言 on 14-8-7.
//  Copyright (c) 2014年 ___李言___. All rights reserved.
//

#import "SecondViewController.h"
#import <CoreText/CoreText.h>
#import "FaceAndTopicLabel.h"
@interface SecondViewController ()
{

    FaceAndTopicLabel *label;
}
@property (nonatomic , strong) EmojiTextView  * mytextView;
@end

@implementation SecondViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    
      
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"%s",__FUNCTION__);
    
    label = [[FaceAndTopicLabel alloc] initWithFrame:CGRectMake(0, 50, 300, 300)];
     label.backgroundColor = [UIColor greenColor];
    label.textColor = [UIColor blackColor];
    label.font= [UIFont  systemFontOfSize:15];
    label.numberOfLines = 0;
    facemap = [NSDictionary dictionaryWithContentsOfFile:
               [[NSBundle mainBundle] pathForResource:@"Emoji"
                                               ofType:@"plist"]];
    __weak NSDictionary * weakDic = facemap;
    label.faceImageForFaceTextBlock = ^UIImage *(NSString * name){
        
        NSString * imgName = [weakDic valueForKey:name];
        if (imgName)
        {
            return [UIImage imageNamed:imgName];
        }
        return nil;
    };
    label.tapTopicBlock = ^(id data){
        NSLog(@"tapTopicBlock %@",data);
    };
    label.topicArray = [NSArray arrayWithObjects:@"#测试#",@"#测试1#", nil];
    
    label.text = @"眼睛asdflhlkl试数[眼睛]sdfw[眼睛]的sdawadwqd[眼睛]o据侧查[眼睛]看正确与否眼睛测[眼睛]ab[眼睛]dfsbesdf数据[眼睛]看正[眼睛]与否#测试##测试1#tdfsdadd将默认黑体字设置为其它字体#测试1##测试#";
//    label.text = @"将大学志愿从[眼睛]一专[眼睛]科[眼睛]总共八个志[眼睛]愿全部填成中央戏剧学[眼睛]院将大学志愿从一本到专科总共八个志愿全部填成[眼睛]中央戏剧学院将大学志[眼睛]愿从一本到专科总共八个志愿全部填成中央戏剧学院";
    
    [self.view addSubview:label];
    
    [label sizeToFit];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(200, 220, 40, 40) ;
    btn.backgroundColor= [UIColor blueColor];
    [btn addTarget:self action:@selector(faceBtnClick:) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:btn];
    
     _mytextView = [[EmojiTextView alloc] initWithFrame:CGRectMake(0, 250, 320, 60)];
    
    _mytextView.inputAccessoryView = btn;
    //textfield.borderStyle =UITextBorderStyleLine;
    _mytextView.delegate = self;
    _mytextView.backgroundColor= [UIColor redColor];

    _mytextView.emojiNameArray = [facemap allKeys];
    [self.view addSubview:_mytextView];
    
   // __weak SecondViewController *this =self;
    if (!faceView) {
        faceView = [[FaceView alloc] init];
        faceView.autoresizingMask = UIViewAutoresizingNone;
        faceView.delegate = self;
        faceView.ClickFaceBtn = ^(NSString * facename){
            
//            NSLog(@"%@",NSStringFromRange(mytextView.selectedRange));
//            NSRange range = mytextView.selectedRange;
           
            
            
        };
        
      
      // faceView.hidden = YES;
      //  [self.view addSubview:faceView];
        
    }
    if ( !faceBoard) {
        
//        faceBoard = [[FaceBoard alloc] init];
//        faceBoard.delegate = self;
//        faceBoard.inputTextView = mytextView;
    }
    
//    [_mytextView becomeFirstResponder];
//
//    [self faceBtnClick:btn];
}


-(void)backFace{


    [self.mytextView removePartTextStringWithStartRangeLocation:self.mytextView.selectedRange.location];



}

-(void)ClickFaceName:(NSString *)faceName{
    
    NSString * imgName = [facemap objectForKey:faceName];
    UIImage * img = [UIImage imageNamed:imgName];
    
    
    [self.mytextView addFaceViewImageWithImageName:faceName andImage:img];
    

    NSString * postStr = [self.mytextView currentPostString];
    NSLog(@"postStr  %@ string %@",postStr,self.mytextView.attributedText.string);
    
    return;
    
    
    NSString * totalStr = @"&&&&&&&&";
    
    NSMutableAttributedString * previous = [[NSMutableAttributedString alloc] initWithString:totalStr];
    
    NSMutableString * total = [NSMutableString stringWithString:previous.string];
    
    NSTextAttachment * textAttachment = [[ NSTextAttachment alloc ] initWithData:nil ofType:nil ] ;
    textAttachment.image = img ;
    
    NSAttributedString * textAttachmentString = [ NSAttributedString attributedStringWithAttachment:textAttachment ] ;
    [previous insertAttributedString:textAttachmentString atIndex:3];
    [previous insertAttributedString:textAttachmentString atIndex:4];
    
//    NSTextAttachment * app = [[NSTextAttachment alloc] initWithData:[@"TTTT" dataUsingEncoding:NSUTF8StringEncoding] ofType:]
//    [previous appendAttributedString:textAttachmentString];
//    [previous addAttribute:(NSString *)kCTForegroundColorAttributeName
//                        value:(id)[UIColor redColor].CGColor
//                        range:NSMakeRange(0, 4)];

    NSLog(@"[previous length] %lu %lu",(unsigned long)[previous length],(unsigned long)[totalStr length]);
    NSAttributedString * subStr = [previous attributedSubstringFromRange:NSMakeRange(0, 1)];
    NSRange range = NSMakeRange(0, 1);
    NSDictionary * dic = [previous attributesAtIndex:3 effectiveRange:&range];
    
    
    NSLog(@"subStr %@ %@ %@",[subStr string],dic,NSStringFromRange(range));
    
    
    self.mytextView.attributedText = previous;
    
    
    
    
    NSLog(@"attributedText%@attributedText%@attributedText%@string",self.mytextView.text,[self.mytextView.attributedText string],self.mytextView.textStorage.string);
    
//    [self textViewDidChange:_mytextView];


}
-(void)faceBtnClick:(UIButton *)sender{
NSLog(@"%s",__FUNCTION__);
   // faceView.hidden = NO;
    
    isFacebord = !isFacebord;
    [_mytextView resignFirstResponder];
    
    [UIView animateWithDuration:0.5
                     animations:^{
                     } completion:^(BOOL finished) {

                         if (isFacebord)
                         {
                             _mytextView.inputView = nil;
                         }else
                         {
                             _mytextView.inputView = faceView;
                         }
                        [_mytextView becomeFirstResponder];
                     }];

    
//    if (!isFacebord) {
//        [_mytextView resignFirstResponder];
//        _mytextView.inputView=faceView;
//        NSLog(@"%@",NSStringFromCGRect(_mytextView.inputView.frame));
//       [UIView animateWithDuration:3 animations:^{
////        faceView.hidden = NO;
////        
////         
//       } completion:^(BOOL finished) {
//             [_mytextView becomeFirstResponder];
//       }];
//        
//      
//       isFacebord=YES;
//    
////       
//    }else{
//        
//        [_mytextView resignFirstResponder];
//        _mytextView.inputView = nil;
//        isFacebord=NO;
//        [UIView animateWithDuration:3 animations:^{
//            
//            
//            
//        } completion:^(BOOL finished) {
//       [_mytextView becomeFirstResponder];
//        }];
//      
//        
//       
//    
//    }

}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
   
    NSLog(@"range = %@  text = %@",NSStringFromRange(range),text);
    
    if ([text isEqualToString:@"\n"]) {
        
        [_mytextView resignFirstResponder];//隐藏键盘
        
//        if ([_revertTxtView.text isEqualToString:@""]) {
//            placeholderLbl.text = @"添加评论...";
//            _revertTxtView.text = @"";
//            _revertTxtView.height = KRevertTextView_Height;
//            reviertTextBack.height = KRevertTextView_Height;
//            return YES;
        
        }

    return YES;

}
- (void)textViewDidChange:(UITextView *)textView{
   
  label.text = textView.text;
}


-(void)loaddata{
 
   [super loaddata];
    NSLog(@"%s",__FUNCTION__);
 
    array = [NSArray array];
    NSLog(@"%@",array);

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
