//
//  FaceViewTableViewCell.m
//  ViewControllerTest
//
//  Created by 李言 on 14-8-11.
//  Copyright (c) 2014年 ___李言___. All rights reserved.
//

#import "FaceViewTableViewCell.h"
#define NumPerLine 7
#define Lines    4
#define FaceSize  24
/*
 ** 两边边缘间隔
 */
#define EdgeDistance 20
/*
 ** 上下边缘间隔
 */
#define EdgeInterVal 20

#import "FaceView.h"
@implementation FaceViewTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        faceMap = [NSDictionary dictionaryWithContentsOfFile:
                    [[NSBundle mainBundle] pathForResource:@"Emoji"
                                                    ofType:@"plist"]];
//        rootView = [UIView alloc] initWithFrame: CGRectMake(0, 0, 320, FaceKeyBoardHeight);
//        [self.contentView addSubview:rootView]
        //
        NSLog(@"%@",NSStringFromCGRect(self.frame));
       self.frame = CGRectMake(0, 0, 320, FaceKeyBoardHeight);
        
    }
    return self;
}

-(void)layOutFaceView:(NSInteger)index{

    
    
    for (UIView * aView in self.contentView.subviews) {
        [aView removeFromSuperview];
    }
    
    // 水平间隔
    CGFloat horizontalInterval = (CGRectGetWidth(self.bounds)-NumPerLine*FaceSize -2*EdgeDistance)/(NumPerLine-1);
    // 上下垂直间隔
    CGFloat verticalInterval = (CGRectGetHeight(self.bounds)-2*EdgeInterVal -Lines*FaceSize)/(Lines-1);
    NSLog(@"%f,%f",horizontalInterval,verticalInterval);
    NSLog(@"%f,%f",verticalInterval,CGRectGetHeight(self.bounds));
    
    for (int i = 0; i<Lines; i++)
    {
        for (int x = 0;x<NumPerLine;x++)
        {
            if ([faceMap count] > index*(NumPerLine*Lines-1)+i*NumPerLine+x+1) {
            
        
            UIButton *expressionButton =[UIButton buttonWithType:UIButtonTypeCustom];
            [self.contentView addSubview:expressionButton];
            [expressionButton setFrame:CGRectMake(x*FaceSize+EdgeDistance+x*horizontalInterval,
                                                  i*FaceSize +i*verticalInterval+EdgeInterVal,
                                                  FaceSize,
                                                  FaceSize)];
                
          //  expressionButton.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin|UIViewAutoresizingFlexibleTopMargin;
                
            if (i*7+x+1 ==NumPerLine*Lines) {
                [expressionButton setBackgroundImage:[UIImage imageNamed:@"face_del_ico_dafeult.png"]
                                            forState:UIControlStateNormal];
                expressionButton.tag = 0;
                
            }else{
            
                NSString *imageStr = [faceMap objectForKey:[[faceMap allKeys] objectAtIndex:index*(NumPerLine*Lines-1)+i*NumPerLine+x+1]];
                [expressionButton setBackgroundImage:[UIImage imageNamed:imageStr]
                                            forState:UIControlStateNormal];
               // NSLog(@"%@",imageStr);
                expressionButton.tag = (NumPerLine*Lines-1)*index+i*NumPerLine+x+1;
            }
            [expressionButton addTarget:self
                                 action:@selector(faceClick:)
                       forControlEvents:UIControlEventTouchUpInside];
        }
        }
    }



}

- (void)faceClick:(id)sender {
    
    long i = ((UIButton*)sender).tag;
    if (self.inputTextView) {
    
        NSMutableString *faceString = [[NSMutableString alloc]initWithString:self.inputTextView.text];
        [faceString appendString:[[faceMap allKeys] objectAtIndex:i]];
    
        self.inputTextView.text = faceString;
        

    }
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
