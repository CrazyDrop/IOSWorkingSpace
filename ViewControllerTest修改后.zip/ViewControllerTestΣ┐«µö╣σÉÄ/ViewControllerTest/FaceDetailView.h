//
//  FaceDetailView.h
//  ViewControllerTest
//
//  Created by 李言 on 14-8-11.
//  Copyright (c) 2014年 ___李言___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FaceDetailView : UIView

{
    NSDictionary *faceMap;
    
}



-(void)layOutFaceView:(NSInteger)index;
@property (nonatomic, strong) UITextView *inputTextView;
@property (nonatomic, strong)void (^ClickFaceButton) (NSString * facename);

@property (nonatomic, strong)void (^BackFace)();

@end
